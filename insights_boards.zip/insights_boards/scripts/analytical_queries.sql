-- ====================================================================
-- Project: InsightBoard Customer Analytics - Core Audit Queries
-- ====================================================================

-- 1. Executive Aggregations vs. Domain Targets
SELECT 
    BusinessDomain,
    COUNT(DISTINCT CustomerID) AS Total_Customers,
    ROUND(AVG(TotalRevenue_USD), 2) AS Avg_Lifetime_Value,
    ROUND(AVG(AvgOrderValue_USD), 2) AS Avg_Order_Value,
    ROUND(AVG(AcquisitionCost_USD), 2) AS Avg_CAC,
    ROUND((SUM(TotalRevenue_USD) - SUM(AcquisitionCost_USD)) / SUM(AcquisitionCost_USD) * 100, 2) AS Marketing_ROI_Percent
FROM customer_analytics.raw_data
GROUP BY BusinessDomain
ORDER BY Total_Customers DESC;

-- 2. Behavioral Segmentation Matrix
WITH Customer_Cohort AS (
    SELECT 
        CustomerSegment,
        PurchaseFrequency,
        COUNT(CustomerID) AS Customer_Count,
        SUM(NumberofPurchases) AS Total_Purchases,
        SUM(TotalRevenue_USD) AS Total_Segment_Revenue
    FROM customer_analytics.raw_data
    GROUP BY CustomerSegment, PurchaseFrequency
)
SELECT 
    CustomerSegment,
    PurchaseFrequency,
    Customer_Count,
    Total_Purchases,
    ROUND(Total_Segment_Revenue, 2) AS Total_Segment_Revenue,
    ROUND((Total_Segment_Revenue / SUM(Total_Segment_Revenue) OVER(PARTITION BY CustomerSegment)) * 100, 2) AS Revenue_Contribution_Percent
FROM Customer_Cohort
ORDER BY CustomerSegment, Total_Segment_Revenue DESC;