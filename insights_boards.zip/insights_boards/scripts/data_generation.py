import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random

np.random.seed(42)
random.seed(42)

NUM_RECORDS = 10245  
DOMAINS = ['Domain A (Retail)', 'Domain B (SaaS)', 'Domain C (Logistics)']
REGIONS = ['North America', 'Europe', 'APAC', 'South America']
SEGMENTS = ['High-Value', 'Frequent', 'New', 'At-Risk']
PURCHASE_FREQUENCY = ['Weekly', 'Monthly', 'Quarterly', 'Annually']

customer_ids = [f'CUST-{i+10000}' for i in range(NUM_RECORDS)]
domains = np.random.choice(DOMAINS, NUM_RECORDS, p=[0.5, 0.3, 0.2]) 
regions = np.random.choice(REGIONS, NUM_RECORDS, p=[0.4, 0.3, 0.2, 0.1])
segments = np.random.choice(SEGMENTS, NUM_RECORDS, p=[0.25, 0.40, 0.20, 0.15])
frequency = np.random.choice(PURCHASE_FREQUENCY, NUM_RECORDS, p=[0.15, 0.45, 0.30, 0.10])

start_date = datetime(2022, 1, 1)
end_date = datetime(2023, 12, 31)
days_between_dates = (end_date - start_date).days
signup_dates = [start_date + timedelta(days=random.randrange(days_between_dates)) for _ in range(NUM_RECORDS)]

base_revenue = np.where(domains == 'Domain B (SaaS)', 1200, 150)
total_revenue = base_revenue + np.random.normal(500, 200, NUM_RECORDS)
total_revenue = np.maximum(total_revenue, 50) 
total_revenue = np.where(segments == 'High-Value', total_revenue * 2.5, total_revenue)

num_purchases = np.random.randint(1, 50, NUM_RECORDS)
num_purchases = np.where(frequency == 'Weekly', num_purchases * 2, num_purchases)
num_purchases = np.where(frequency == 'Annually', np.random.randint(1, 3, NUM_RECORDS), num_purchases)

avg_order_value = total_revenue / num_purchases
customer_acq_cost = np.random.uniform(10, 150, NUM_RECORDS)
days_since_start = np.array([(d - start_date).days for d in signup_dates])
total_revenue = total_revenue * (1 + (days_since_start / days_between_dates) * 0.15)

df = pd.DataFrame({
    'CustomerID': customer_ids,
    'SignupDate': signup_dates,
    'BusinessDomain': domains,
    'Region': regions,
    'CustomerSegment': segments,
    'PurchaseFrequency': frequency,
    'TotalRevenue_USD': np.round(total_revenue, 2),
    'NumberofPurchases': num_purchases,
    'AvgOrderValue_USD': np.round(avg_order_value, 2),
    'AcquisitionCost_USD': np.round(customer_acq_cost, 2),
    'LastPurchaseDate': [d + timedelta(days=random.randrange(1, 90)) for d in signup_dates]
})

df['LastPurchaseDate'] = df['LastPurchaseDate'].clip(upper=pd.Timestamp(end_date))
df.to_csv('synthetic_customer_data.csv', index=False)
print("Dataset successfully saved as 'synthetic_customer_data.csv'.")